﻿using UnityEngine;
using System;
using System.IO;

public class SaveLoadManager : MonoBehaviour {

    public string filename;

    static SaveLoadManager _instance;

    public static SaveLoadManager instance {
        get {
            if (_instance == null)
            {
                _instance = FindObjectOfType<SaveLoadManager>();

                if (FindObjectOfType<SaveLoadManager>() == null)
                {
                    GameObject slManager = new GameObject("SaveLoadManager");
                    slManager.AddComponent<SaveLoadManager>();
                    _instance = slManager.GetComponent<SaveLoadManager>();

                }
            }

            return _instance;
        }
    }

    public void SaveData(string data, string fileName) {
        string filePath = Application.persistentDataPath;
        StreamWriter sw = new StreamWriter(filePath + "/" + fileName);
        sw.Write(data);
        sw.Close();
    }

    public string LoadData(string fileName) {
        string filePath = Application.persistentDataPath;
        string fileData = "";

        if (Directory.Exists(filePath))
        {
            FileStream file = File.Open(filePath + "/" + fileName, FileMode.Open);
            StreamReader sr = new StreamReader(file);

            fileData = sr.ReadToEnd();

            sr.Close();
            file.Close();
        }

        return fileData;
    }
}
