﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ArticleGenerator : MonoBehaviour
{

    public string header;
    public string author;

    public string[] randomWords;
    public int wordCount;
    public int paragraphs;
    public int indentSpaces;

    public bool addConclusion;
    public string conclusion;

    public Text articleTextfield;

    string article;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            CreateArticle();
        }
    }

    public void CreateArticle()
    {
        //  reset article
        article = "";

        //  create header
        article += CreateSentence(header, false) + "\n";

        //  create by-line
        article += "By " + CreateSentence(author, false) + "\n\n";

        //  create body

        string randomWord = randomWords[Random.Range(0, randomWords.Length)];
        int paragraphWordCount = (int)Mathf.Ceil(wordCount / paragraphs);

        for (int i = 0; i < paragraphs; i++)
        {
            article += CreateParagraph(randomWords, paragraphWordCount, 5);
        }

        //  add conclusion, if requested
        if (addConclusion)
        {
            if (!string.IsNullOrEmpty(conclusion))
            {
                article += "\n" + conclusion + ".";
            }
        }

        //  write to information
        articleTextfield.text = article;
    }

    string CreateSentence(string _sentence)
    {
        string newSentence = "";
        if (_sentence != null || _sentence != "")
            newSentence = _sentence;

        return newSentence;
    }

    string CreateSentence(string _sentence, bool addPeriod)
    {

        string newSentence = "";

        if (_sentence != null || _sentence != "")
        {
            if (addPeriod)
                newSentence = _sentence + ".";
            else
                newSentence = _sentence;
        }

        return newSentence;
    }

    string CreateSentence(int wordCount, string[] _sentenceWords)
    {
        string _sentence = "";
        string randomWord = _sentenceWords[Random.Range(0, _sentenceWords.Length)];

        //continued part or word
        for (int i = 0; i < wordCount; i++)
        {
            if (i == 0)
            {
                if (_sentenceWords.Length == 1 || wordCount == 1)
                {
                    _sentence += char.ToUpper(randomWord[0]) + randomWord.Substring(1);
                }
                else {
                    _sentence += char.ToUpper(randomWord[0]) + randomWord.Substring(1) + " ";
                }
            }
            else {
                _sentence += " " + randomWord;
            }
        }

        _sentence += ".";

        return _sentence;
    }

    string CreateParagraph(string _randomWord, int wordAmount)
    {

        string articleString = "";

        //  start off paragraph with indents
        for (int i = 0; i < indentSpaces; i++)
        {
            articleString += " ";
        }

        //  add words to string
        for (int i = 0; i < wordAmount; i++)
        {
            articleString += _randomWord;
        }

        //  add line retun to end or paragraph
        articleString += "\n";

        return articleString;
    }

    string CreateParagraph(string[] _randomWords, int _wordCount, int _sentenceCount)
    {
        string articleString = "";
        int wordCounter = _wordCount;

        //  create indention
        for (int i = 0; i < indentSpaces; i++)
        {
            articleString += " ";
        }

        //  add sentences to paragraph
        for (int i = 0; i < _sentenceCount; i++)
        {
            if (wordCounter > 0)
            {
                //  add words to sentence based on amt of words left in word counter
                int randomWordCount = Random.Range(1, wordCounter);

                articleString += CreateSentence(randomWordCount, _randomWords);

                //  reduce amount of word counter based on random word count
                wordCounter -= randomWordCount;
            }
        }

        //  add line return for end of paragraph
        articleString += "\n";

        return articleString;
    }

    public void SaveArticle()
    {

        SaveLoadManager.instance.SaveData(article, SaveLoadManager.instance.filename);
        Debug.Log(article);
        Debug.Log("article saved");

    }

    public void LoadArticle()
    {
        article = SaveLoadManager.instance.LoadData(SaveLoadManager.instance.filename);
        Debug.Log(article);
        articleTextfield.text = article;
        Debug.Log("article loaded");
    }
}
